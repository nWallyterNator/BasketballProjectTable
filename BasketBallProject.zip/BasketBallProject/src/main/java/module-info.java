module com.example.basketballproject {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.basketballproject to javafx.fxml;
    exports com.example.basketballproject;

    opens model to javafx.base;
    exports model;
}